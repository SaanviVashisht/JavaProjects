public class Main
{
	public static void main(String[] args) {
		ComplexNumber z1 = new ComplexNumber(3, 4);
		ComplexNumber z2 = new ComplexNumber(1, -2);
		
		System.out.println(z1.add(z2));
		System.out.println(z1.subtract(z2));
		System.out.println(z1.multiply(z2));
		System.out.println(z1.divide(z2));
		System.out.println(z1.absoluteValue());
	}
}
