public class ComplexNumber {
    private double a, b;
    
    public ComplexNumber(double a, double b) {
        this.a = a;
        this.b = b;
        
    }
    
    public ComplexNumber add(ComplexNumber z) {
     double realNumber = this.a+ z.a;
     double imaginaryNumber = this.b+z.b;
     return new ComplexNumber(realNumber,imaginaryNumber);
    }
    
    public ComplexNumber subtract(ComplexNumber z) {
     double realNumber = this.a - z.a;
     double imaginaryNumber = this.b-z.b;
     return new ComplexNumber(realNumber,imaginaryNumber);
    }
    
    public ComplexNumber multiply(ComplexNumber z) {
        double first = (this.a*z.a);//a1a2
        double second = (this.a*z.b);//a1b2
        double third = (this.b*z.a); //a2b1
        double fourth = (this.b*z.b); //b1b2
        double finalAnsReal = (first-fourth);
        double finalAnsImaginary = (second+third);
        return new ComplexNumber(finalAnsReal,finalAnsImaginary);
    }
    
    public ComplexNumber divide(ComplexNumber z) {
        double first = (this.a*z.a);//a1a2
        double second = (this.a*z.b);//a1b2
        double third = (this.b*z.a); //a2b1
        double fourth = (this.b*z.b); //b1b2
        double denominator = (z.a)*(z.a)+(z.b)*(z.b);
        double firstFraction = (first+fourth)/denominator;
        double secondFraction = (third-second)/denominator;
        return new ComplexNumber(firstFraction,secondFraction);
    }
    
    public double absoluteValue() {
        double initialVal = ((this.a)*(this.a)+(this.b)*(this.b));
        double absVal = Math.sqrt(initialVal);
        return absVal;
    }
    
    public String toString() {
        String s= this.a+" "+"+"+" "+(this.b)+"i";
        return s;
    }
    
    //determines if a given complex number is in the Mandelbrot Set
    public boolean isInMandelbrot() {
        return false;
    }
}