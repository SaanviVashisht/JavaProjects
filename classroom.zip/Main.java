public class Main
{
	public static void main(String[] args) {
	Classroom aBlock = new Classroom(4, 4);
    Student s1 = new Student("Kelly", "Kapowski", 'p');
    Student s2 = new Student("Zack", "Morris", 't');
    Student s3 = new Student("Jessie", "Spano", 'p');
    aBlock.addStudent(s1, 0, 1);
    aBlock.addStudent(s2, 1, 1);
    aBlock.addStudent(s3, 2, 1);
    aBlock.addStudent(new Student("Alan","Turing",'p'));
    System.out.println(aBlock);
    aBlock.takeAttendance();
	}
}
