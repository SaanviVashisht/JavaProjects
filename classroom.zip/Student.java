public class Student {
    private String firstName, lastName;
    private Character attendanceCode; //p(present), a(absent), t(tardy), n(not taken)
    
    public Student(String firstName, String lastName, Character attendanceCode) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.attendanceCode = attendanceCode;
    }
    
    public Student(String firstName, String lastName){
        this.firstName = firstName;
        this.lastName = lastName;
        this.attendanceCode = 'n';
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public Character getAttendanceCode() {
        return attendanceCode;
    }
    
    public void setAttendance(Character newCode) {
        attendanceCode = newCode;
    }
    
    public String getInitials() {
    return "" + firstName.charAt(0) + lastName.charAt(0);
}
}