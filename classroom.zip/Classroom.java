import java.util.Scanner;
public class Classroom {
	private Student[][] seatingChart;

	public Classroom(int rows, int cols) {
		seatingChart = new Student[rows][cols];
	}

	public void addStudent(Student s, int row, int col) {
		if (this.seatingChart[row][col]==null) {
			seatingChart[row][col] = s;
		}
		else {
			System.out.println("Sorry, this seat is taken!");
		}
	}

	public void addStudent(Student s) {
		for(int i=0; i<seatingChart.length; i++) {
			for(int j=0; j<seatingChart[i].length; j++) {
				if (seatingChart[i][j]==null) {
					seatingChart[i][j]=s;
					return;
				}
			}
		}

	}
public 
	public String toString() {
		String str = "";
		for (int i = 0; i < seatingChart.length; i++) {
			for (int x = 0; x < seatingChart[i].length; x++) { //This for loop is for the dashes
				str += "------";
			}
			str += "-\n";

			for (int j = 0; j < seatingChart[i].length; j++) {
				if (seatingChart[i][j] == null) {
					str += "|     ";
				} else {
					str += "|" + seatingChart[i][j].getInitials() + "   ";
				}
			}
			str += "|\n";
			for (int j = 0; j < seatingChart[i].length; j++) {
				if (seatingChart[i][j] == null) {
					str += "|     ";
				} else {
					str += "|  " + seatingChart[i][j].getAttendanceCode() + "  ";
				}
			}
			str += "|\n";
		}
		for (int x = 0; x < seatingChart[0].length; x++) {
			str += "------";
		}
		str += "-";

		return str;
	}


	public boolean attendanceTaken() {
		for (int i = 0; i < seatingChart.length; i++) {
			for (int j = 0; j < seatingChart[i].length; j++) {
				if (seatingChart[i][j] != null && seatingChart[i][j].getAttendanceCode() == 'n') {
					return false;
				}
			}
		}
		return true;
	}

	public void takeAttendance() {
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < seatingChart.length; i++) {
			for (int j = 0; j < seatingChart[i].length; j++) {
				Student student = seatingChart[i][j];
				if (student != null) {
					char attendanceCode;
					while (true) {
						System.out.print("Please enter the attendance code for " + student.getInitials() +
						                 " (p = present, a = absent, and t = tardy): ");
						String input = scanner.nextLine().toLowerCase();

						if (input.charAt(0) == 'p' || input.charAt(0) == 'a' || input.charAt(0) == 't') {
							attendanceCode = input.charAt(0);
							break;
						} else {
							System.out.println("INVALID CODE!\nPlease enter p, a, or t!");
						}
					}

					student.setAttendance(attendanceCode);
				}
			}
		}
	}
}