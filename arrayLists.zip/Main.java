import java.util.ArrayList;

public class Main
{
	public static void main(String[] args) {
	    ArrayList<Student>  students=new ArrayList<>();
		Student annabeth = new Student("Annabeth");
		annabeth.addNewScore(90);
		annabeth.addNewScore(95);
		annabeth.addNewScore(97);
		students.add(annabeth);
		Student percy= new Student("Percy");
		percy.addNewScore(85);
		percy.addNewScore(75);
		percy.addNewScore(77);
        students.add(percy);
		Student grover= new Student("Grover");
		grover.addNewScore(75);
		grover.addNewScore(72);
		grover.addNewScore(80);
		students.add(grover);
		Student katniss= new Student("Katniss");
		katniss.addNewScore(80);
		katniss.addNewScore(70);
		katniss.addNewScore(68);
		students.add(katniss);
		Student peeta= new Student("Peeta");
		peeta.addNewScore(95);
		peeta.addNewScore(98);
		peeta.addNewScore(99);
		students.add(peeta);
		Student primrose= new Student("Primrose");
		primrose.addNewScore(98);
		primrose.addNewScore(93);
		primrose.addNewScore(97);
		students.add(primrose);
		
	  for (int i = 0; i < students.size(); i++) {
              System.out.print(students.get(i).getName());
              System.out.print(":");
              System.out.print(students.get(i).getAverageScore());
              System.out.println();
	  }
	 System.out.println("-----------Another way:------------------");
	 for (int i = 0; i < students.size(); i++) {
              System.out.println(students.get(i).toString());
	     
	 }
	
		
	
	}
}
