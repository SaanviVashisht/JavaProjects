public class Student {
    
    private String name; //stores the student's name
	private int numScores; //stores how many assignments have been graded
	private int[] scores; //stores the list of individual assignment scores
    
    public Student(String n) {
 	   name = n;
 	   numScores = 0;
 	   scores = new int[10];
	}
    
    //Adds a new score to the array of scores
    //Once 10 scores have been added the method does nothing
    public void addNewScore(int newScore) {
	   if (numScores < 10) {
 	       scores[numScores] = newScore;
 	       numScores++;    
 	   }
	}
    
    //Computes and returns the current average of all test scores added
    //Do not assume that 10 scores have been added before this method is called
    public int getAverageScore() {   
		int sum = 0;
		for (int i = 0; i < numScores; i++) {
		    sum += scores[i];
		}
		return sum/numScores;
    }
    
    public String getName(){
        return name;
    }
    public String toString(){
        String s = "Name: "+ name+ "| Average Score: " + getAverageScore();
        return s;
    }
    }