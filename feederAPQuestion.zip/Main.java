public class Main {
    public static void main(String[] args) {

        int startingAmountOfFood = ;  
        int count = 0;

        for (int i = 1; i <= 100; i++) {
            Feeder myFeeder = new Feeder(startingAmountOfFood);
            int days = myFeeder.returnTheDays();

            if (days==5) {
                count++;
            }
        }

        System.out.println("Number of successful days with food: " + count);
    }
}