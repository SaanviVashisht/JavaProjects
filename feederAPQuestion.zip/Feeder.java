public class Feeder {
    private int currentFood;
    
    public Feeder(int food) {
        this.currentFood = food;
    }

    public void simulateOneDay(int numBirds) { 
        double isBirdOrBear;
        int amountOfFoodEaten;
        int finalAmountOfFoodEaten;
        int min = 10;
        int max = 50;

        amountOfFoodEaten = (int)(Math.random() * ((max - min) + 1)) + min;
        finalAmountOfFoodEaten = amountOfFoodEaten * numBirds;
        
        isBirdOrBear = Math.random();
        
        if (isBirdOrBear < 0.95) {
            if (finalAmountOfFoodEaten > this.currentFood) {
                this.currentFood = 0;  
            } else {
                this.currentFood = currentFood - finalAmountOfFoodEaten; 
            }
        } else {
            this.currentFood = 0;
        }
    }   

    public int returnTheDays() {
        int daysElapsed = 0;
        int minNumberOfBirds = 10;
        int maxNumberOfBirds = 12;
        int numberOfBirds = 0;
        
        while (this.currentFood > 0) {
            
             numberOfBirds = (int)(Math.random() * 
                ((maxNumberOfBirds - minNumberOfBirds) + 1)) + minNumberOfBirds;

            simulateOneDay(numberOfBirds);
            daysElapsed++;
        }

        return daysElapsed;  
    }

    public int simulateManyDays(int numBirds, int numDays) {
        int count = 0;

        for (int i = 1; i <= numDays; i++) {
            if (this.currentFood > 0) {
                simulateOneDay(numBirds);
                count++;
            }
        }

        return count;
    }

    public String toString() {
        return "The current food is: " + currentFood;
    }
}