import java.util.Scanner;
import java.util.Arrays;

public class Main
{
	public static void main(String[] args) {
		double[] nums = new double[5];
		double sum = 0;
		for (int y = 0; y<nums.length; y++) {
			System.out.print("Please enter a double value: ");
			Scanner scanner = new Scanner(System.in);
			double x = scanner.nextDouble();
			nums[y]=x;
			sum=sum+nums[y];

		}
        System.out.println(Arrays.toString(nums));
		System.out.println(sum);
		System.out.println(sum/nums.length);

		System.out.print("Please enter another double value: ");
		Scanner scanner1 = new Scanner(System.in);
		double z = scanner1.nextDouble();
        for (int y = 0; y<nums.length;y++){
		if (nums[y]>z) {
		    System.out.println(nums[y]);
		}
        }

	}

}