public class Matrix {
    private int[][] mat;
    
    
    public Matrix(int numRows, int numCols) {
        this.mat = new int[numRows][numCols];
       
    }
    
    public int getValue(int r, int c){
        return mat[r][c];
    }
    
    public void setValue(int r, int c, int newValue){
        this.mat[r][c]=newValue;
}
    
    
    public String toString(){
        String s = "";
        for(int i=0; i<this.mat.length; i++){
            for(int j=0; j<this.mat[i].length; j++){
                s = s+ mat[i][j]+" ";
            }
            s=s+"\n";
        }
        return s;
    }
    
    public void fill(int value){
        for(int i=0; i<this.mat.length; i++){
            for(int j=0; j<this.mat[i].length; j++){
               this.mat[i][j] = value;
            }
        }
    }
    
    public void clear(){
        fill(0);
    }

    public int sumRow(int r){
        int sum = 0;
        for(int j = 0; j < this.mat[r].length; j++){
            sum += this.mat[r][j];
        }
        return sum;
    }
    
    public int sumCol(int c){
        int sum = 0;
        for(int i = 0; i < this.mat.length; i++){
            sum += this.mat[i][c];
        }
        return sum;
    }
    public int numOccurences(int target){
        int count = 0;
        for(int i=0; i<this.mat.length; i++){
            for(int j=0; j<this.mat[i].length; j++){
               if (this.mat[i][j] == target){
                   count++;
               }
    }
    }
    return count;
}
    public int numZeroes(){
        return numOccurences(0);
    }
      public void rowSwap(int r1, int r2){
        int[] temp = this.mat[r1];
        this.mat[r1] = this.mat[r2];
        this.mat[r2] = temp;
    }
}

