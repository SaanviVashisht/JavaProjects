import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
    
    Scanner s = new Scanner(System.in);
    
    System.out.println("How many rows? ");
    int rows = Integer.parseInt(s.nextLine());
    
    System.out.println("How many cols? ");
    int columns = Integer.parseInt(s.nextLine());
    
    Matrix sample = new Matrix(rows, columns);
    //System.out.println(sample);
	
	String input = " ";
	String [] userInput;
	
	while(!input.equals("done")){
	
	System.out.println("Enter an element to set (row col value), or 'done' to finish ");
    input = s.nextLine().toLowerCase();

    if (!input.equals("done")) {
        userInput = input.split(" ");
        int row = Integer.parseInt(userInput[0]);
        int col = Integer.parseInt(userInput[1]);
        int value = Integer.parseInt(userInput[2]);
        sample.setValue(row, col, value);
    }
}
    System.out.println(sample);
}
}