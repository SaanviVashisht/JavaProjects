public class Colony {

	//This stores the colony data.
	private int[][] colony;

	//This creates a square colony of the size the user enters when they create an instance of this class
	public Colony(int size) {
		this.colony = new int[size][size];   //This automatically fills the array with 0s
	}

	//This method sets a specific cell alive
	public void setCellAlive(int row, int col) {
		this.colony[row][col] = 1;
	}

	//This method sets a specific cell dead
	public void setCellDead(int row, int col) {
		this.colony[row][col] = 0;
	}

	//This method returns a string representation of the colony
	//We create an abstraction so that the user only sees the symbols "X" for dead cells
	//and "*" for living cells. Under the hood, 0 indicates dead cells and 1 indicates living
	//cells
	public String toString() {
		String s = "";
		for (int i = 0; i < this.colony.length; i++) {
			for (int j = 0; j < this.colony[i].length; j++) {
				if (this.colony[i][j] == 1) {
					s += "* ";
				} else {
					s += "X ";
				}
			}
			s += "\n";   //add newline after each row
		}
		return s;
	}

	//This method checks if a row and column are within bounds
	private boolean isInBounds(int row, int col) {
		return row >= 0 && row < colony.length && col >= 0 && col < colony[row].length;
	}

	//This method counts the number of living neighbors for a certain cell
	private int numLivingNeighbors(int row, int col) {
		int count = 0;

		for (int i = row - 1; i <= row + 1; i++) {
			for (int j = col - 1; j <= col + 1; j++) {
				//This ensures only the neighboring cells are counted
				if ((i != row || j != col) && isInBounds(i, j)) {
					count += colony[i][j];
				}
			}
		}

		return count;
	}
	//This method evolves the colony by one generation
	public void evolve() {
		int size = colony.length;
		int[][] nextGeneration = new int[size][size];

		for (int row = 0; row < size; row++) {
			for (int col = 0; col < size; col++) {
				int neighbors = numLivingNeighbors(row, col);
				if (colony[row][col] == 1) { //A cell that is currently alive
					if (neighbors < 2 || neighbors > 3) {
						nextGeneration[row][col] = 0; //This cell dies
					} else {
						nextGeneration[row][col] = 1; //The cell stays alive
					}
				} else { //This cell is currently dead
					if (neighbors == 3) {
						nextGeneration[row][col] = 1; //Now it becomes becomes alive
					} else {
						nextGeneration[row][col] = 0; //The cell stays dead
					}
				}
			}
		}

		colony = nextGeneration; //This updates colony to the next generation
	}
}