import java.util.Scanner;

public class ColonyVC {

	public void runSystem() {
		Scanner scanner = new Scanner(System.in);

		//Asks the user for the colony size
		System.out.println("Enter the size of your colony.");
		System.out.print("-> ");
		int size = Integer.parseInt(scanner.nextLine());
		Colony colony = new Colony(size); //Creates a colony of size "size"

		//Asks the user for the initial living cells
		System.out.println("\nEnter living cells in the form \"row col\". Enter blank to stop.");
		while (true) {
			System.out.print("-> ");
			String input = scanner.nextLine().trim();

			//Stops entering cells if user presses Enter without typing anything
			if (input.isEmpty()) break;

			//Splits the input into row and column using a single space
			String[] parts = input.split(" ");
			if (parts.length != 2) {
				System.out.println("Invalid input. Please enter the row and col separated by a single space.");
				continue;
			}

			//Only parses row/col if both are integers
			if (isInt(parts[0]) && isInt(parts[1])) {
				int row = Integer.parseInt(parts[0]);
				int col = Integer.parseInt(parts[1]);

				colony.setCellAlive(row, col); // Sets the cell as alive
			}
		}

		//Prints the initial colony (Generation 0)
		int generation = 0;
		System.out.println("\nGeneration: " + generation);
		System.out.println(colony.toString());

		//Evolution loop
		while (true) {
			System.out.println("\nPress 'ENTER' to evolve, a number for multi-evolve or 'q' to quit.");
			System.out.print("-> ");
			String input = scanner.nextLine().trim();

			//Stops simulation if the user types 'q'
			if (input.equals("q")) break;

			//Determines how many generations to evolve
			int evolutions = 1; // Default is 1
			if (!input.isEmpty() && isInt(input)) {
				evolutions = Integer.parseInt(input); // Parse number of generations
			}

			//Evolves colony and prints each generation
			for (int i = 0; i < evolutions; i++) {
				colony.evolve();
				generation++; // Increment generation
				System.out.println("\nGeneration: " + generation);
				System.out.println(colony.toString());
			}
		}

		scanner.close();
		System.out.println("Simulation ended.");
	}

	//Boolean method to check if a string is an integer
	public static boolean isInt(String s) {
		try {
			Integer.parseInt(s);
			return true;
		} catch(NumberFormatException e) {
			return false;
		}
	}
}