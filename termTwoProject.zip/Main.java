public class Main {
    public static void main(String[] args) {
        ColonyVC tester = new ColonyVC();
        tester.runSystem();  
    }
}