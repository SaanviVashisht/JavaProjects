public class Main
{
	public static void main(String[] args) {
	    /*
	        In Java, primitive arrays...
	        -are fixed size upon declaration
	        -are of a homogenous (same) type
	        -are object types, meaning they can be broken down
	        -allow direct access to individual elements
	        -have a .length property
	    */
	    
	    //creates an array object of int types of length 10
		int[] nums = new int[10];
		
		//use a literal expression to initialize a new array object
		int[] otherNums = {90, 93, 92, 80, 78};
		
		//access elements directly
		System.out.println(otherNums[3]);
		System.out.println(nums[0]);
		//trying to access an index that is out of bounds
		//System.out.println(nums[10]);
		
	    //modifying an element directly
	    otherNums[0] = 91;
	    
	    //testing methods that require array parameters
	    ArrayMethods am = new ArrayMethods();
	    am.printIntArray(nums);
	    System.out.println();
	    am.printIntArray(otherNums);
	    System.out.println("------------");
	    System.out.println(am.sumIntArray(otherNums));
	    System.out.println();
	    System.out.println(am.averageIntArray(otherNums));
	    System.out.println();
	    System.out.println(am.numEvens(otherNums));
	    System.out.println();
	    System.out.println(am.isStrictlyIncreasing(otherNums));
	}

}
