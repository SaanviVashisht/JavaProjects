public class ArrayMethods {
    
    //takes an int array and displays its contents
    public void printIntArray(int[] arr) {
        //use a variable, i, to iterate through the indices of the array
        for (int i = 0; i < arr.length; i++) {
            System.out.println(i + ": " + arr[i]);
        }
    }
    
     public int sumIntArray(int[] arr) {
        int sum=0;
        for (int i = 0; i < arr.length; i++){
          sum=sum+arr[i];
        }
        return(sum);
    }
    
    public int averageIntArray(int[]arr){
        int average=0;
        for (int i = 0; i < arr.length; i++){
            average=average+arr[i];
        }
        average=average/arr.length;
        return(average);
    }
    public int numEvens(int[]arr){
        int Even=0;
        for (int i=0; i<arr.length;i++){
            if (arr[i]%2==0){
                Even=Even+1;
            }
            
        }
        return Even;
    }
    public boolean isStrictlyIncreasing(int[]arr){
        boolean x = true;
        for(int i=1; i<arr.length;i++){
            if(arr[i]>=arr[i-1]){
                return x== false;
            }
            else{
             return x== true;
            }
        }
        return x;
    }
}
    