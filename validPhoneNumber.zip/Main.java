import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
        int countTotal=0;
        int countImproper=0;
        double percentageImproper;
        try {
        File file = new File("sampleData.txt");
        Scanner input = new Scanner(file);
        while (input.hasNextLine()) {
            String phoneNumber = input.nextLine();

            if (isValidPhoneNumber(phoneNumber)==false) {
                System.out.println(phoneNumber);
                countImproper++;
            }
            countTotal++;
        }

    } catch (FileNotFoundException e) {
        System.out.println("This file is not found.");
    }
    String s = "";
    s=s+ "The total number of phone numbers is: "+countTotal+"\n";
    s=s+"The total number of improperly formatted numbers is: "+countImproper+"\n";
    s=s+"The percentage of improperly formatted numbers is: "+ (((double)countImproper/countTotal)*100) + "%";
    System.out.println(s);
}
	
	public static boolean isValidPhoneNumber(String phoneNumber) {
    //The method checks all the conditions that will return false, if none of these are met the method returns true.
    
    if (phoneNumber.length() != 14) {
        return false;
    }

    for (int i = 1; i <= 3; i++) { //The first three digits  
        if (Character.isDigit(phoneNumber.charAt(i))==false) {
            return false;
        }
    }

    for (int i = 6; i <= 8; i++) { //The next three digits         
        if (Character.isDigit(phoneNumber.charAt(i))==false) {
            return false;
        }
    }

    for (int i = 10; i <= 13; i++) { //The last four digits       
        if (Character.isDigit(phoneNumber.charAt(i))==false) {
            return false;
        }
    }
    //Checks whether the characters and the space is present
    if (phoneNumber.charAt(0) != '(' || phoneNumber.charAt(4) != ')' || phoneNumber.charAt(5) != ' ' ||phoneNumber.charAt(9) != '-') {
        return false;
    }

    return true;
	}
}