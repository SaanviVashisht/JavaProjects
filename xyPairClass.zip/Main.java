public class Main
{
	public static void main(String[] args) {
		/*
		
		WRITE YOUR OWN TEST CODE HERE
		
		You should create 2 instances of the XYPair class. 
		Use these objects to demonstrate all methods of your XYPair class
		
		*/
		
		XYPair firstPoint= new XYPair(1.0,2.0);
		XYPair secondPoint= new XYPair(3.0,4.0);
		
		secondPoint.distanceTo(firstPoint);
	    
	    firstPoint.distanceTo(secondPoint);
	
	    System.out.println("First Point: " + firstPoint); 
	    System.out.println("Second Point: " + secondPoint);
	    System.out.println();
	    System.out.println("Distance between these points:");
	    System.out.println(firstPoint.distanceTo(secondPoint));
	    System.out.println();
	    System.out.println("Slope between these points:");
	    System.out.println(firstPoint.slopeBetween(secondPoint));
	    System.out.println();
	    System.out.println("Equation of line through these points:");
	    System.out.println(firstPoint.equationOfLineThrough(secondPoint));
	}
}
