class XYPair {
    private double x;
    private double y;
    
    public XYPair(double x, double y) {
        this.x = x;
        this.y = y;
    }
     
     //accessor methods for the x and y properties
    public double getX() {return this.x;}
    public double getY() {return this.y;}
    
    public XYPair(){
        this.x = 0;
        this.y = 0;
    }
    
    
    public double distanceTo(XYPair otherPoint) {
        double distanceBetweenXPoints = otherPoint.x-this.x;
        double distanceBetweenYPoints = otherPoint.y-this.y;
        double distance = Math.sqrt((((distanceBetweenXPoints)*(distanceBetweenXPoints)))+((distanceBetweenYPoints)*(distanceBetweenYPoints)));
        return distance;
    }
    
      public double distanceTo(double x, double y) {
        double distanceBetweenXPoints = x-this.x;
        double distanceBetweenYPoints = y-this.y;
        double distance = Math.sqrt((((distanceBetweenXPoints)*(distanceBetweenXPoints)))+((distanceBetweenYPoints)*(distanceBetweenYPoints)));
        return distance;
    }
    
    public double slopeBetween(XYPair otherPoint) {
        double distanceBetweenXPoints = otherPoint.x-this.x;
        double distanceBetweenYPoints = otherPoint.y-this.y;
        double slope = distanceBetweenYPoints/distanceBetweenXPoints;
        return slope;
       
    }
    
    public String equationOfLineThrough(XYPair otherPoint) {
        double distanceBetweenXPoints = otherPoint.x-this.x;
        double distanceBetweenYPoints = otherPoint.y-this.y;
        double slope = distanceBetweenYPoints/distanceBetweenXPoints;
        return "y"+"-"+this.y+ "="+slope+"(x-"+this.x+")";

    }
    
    public String toString() {
        return "("+this.x+","+this.y+")";
        /*
            returns a String formatted as (x, y)
            
            remember that this method is automatically called when 
            printing an XYPair object
        */
    }
}
