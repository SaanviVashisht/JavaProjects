public class LoopTester {
    //Assuming the input given is a positive integer
	public void countDown(int start){
	   System.out.println("countDown");
	    int x = 1;
	    while (x <= start){
	    System.out.println(start);
	    start = start - 1;
    }
     System.out.println("--------");
	}
    
    public int sumOfIntegers(int n){
        System.out.println("sumOfIntegers");
	    int y = 1;
	    int sum = 0;
	    while (y <= n){
	    sum = sum+y;
	    y=y+1;
    }
     return sum;
    }
    
    public int sumOfEvenNumbers(int n){
          System.out.println("sumOfEvenNumbers");
	    int z = 1;
	    int sum1 = 0;
	    while (z <= n){
	    if (z%2==0){
	    sum1 = sum1+z;
	    }
	   
	   z=z+1;
	    }
	    return sum1;
    }
	public int countingMultiples(int n, int k){
	     System.out.println("countingMultiples");
	    int y = 1;
	    int count = 0;
	    while (y <= n){
	    if (y%k==0){
	    count = count+1;
	    }
	    y=y+1;
	    }
	  
	   return count;
    }

    public int countDigits(int n){
         System.out.println("countDigits");
	    int count = 0;
	    int y = n;
	    while (y>0){
	    y = y/10;
	    count=count+1;
	    }
	    return count;
    }
	public int countOddDigits(int n){
	     System.out.println("countOddDigits");
	    int odd = 0;
	    int y = n;
	    int x = 0;
	    while (y>0){
	    x=y%10;
	    y = y/10;
	    if (x%2>0){
	        odd = odd+1;
	        }
	    }
	   return odd;
	    }
	   
    }
