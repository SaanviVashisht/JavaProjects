public class ForLoopTester {
    //Assuming the input given is a positive integer
	public void countDown(int start1){
	    System.out.println("countDown");
	    for (int i = start1; start1>=1; start1=start1-1){
	    System.out.println(start1);
	    }
	    System.out.println("--------");
    }
     
     public int sumOfIntegers(int n){
        System.out.println("sumOfIntegers");
        int sum=0;
        for (int y=1; y<=n; sum=sum+y,y=y+1){
        }
     return sum;
    }
    
     public int sumOfEvenNumbers(int n){
        System.out.println("sumOfEvenNumbers");
        int sum1 = 0;
        for (int z=1; z<=n; z=z+1){
	    if (z%2==0){
	    sum1 = sum1+z;
	    }
	    }
	    return sum1;
    }
    
    public int countingMultiples(int n, int k){
	   System.out.println("countingMultiples");
	   int count = 0;
	   for(int y=1; y<=n; y=y+1 )
	    if (y%k==0){
	    count = count+1;
	    }
	  
	   return count;
    }
    
     public int countDigits(int n){
        System.out.println("countDigits");
        int count = 0;
        for(int y = n; y>0;){
	    y = y/10;
	    count=count+1;
	    }
	    return count;
    }
    
    public int countOddDigits(int n){
	    System.out.println("countOddDigits");
	    int odd = 0;
	    int x = 0;
	    for (int y = n; y>0;){
	    x=y%10;
	    y = y/10;
	    if (x%2>0)
	        odd = odd+1;
	    }
	   return odd;
	    }
	    }
    