public class Main
{
    
	public static void main(String[] args) {
		LoopTester lt = new LoopTester();
		lt.countDown(4);
		//System.out.println(lt.sumOfIntegers(5));
		//System.out.println();
		//System.out.println(lt.sumOfEvenNumbers(7));
		//System.out.println();
		//System.out.println(lt.countingMultiples(15,5));
		//System.out.println();
		//System.out.println(lt.countDigits(12345));
		//System.out.println();
		//System.out.println(lt.countOddDigits(86420));
	    ForLoopTester test = new ForLoopTester();
		test.countDown(4);
		System.out.println(test.sumOfIntegers(5));
		System.out.println(test.sumOfEvenNumbers(7));
		System.out.println(test.countingMultiples(15,5));
		System.out.println(test.countDigits(12345));
		System.out.println(test.countOddDigits(8642013));
}
}
