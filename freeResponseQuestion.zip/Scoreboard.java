public class Scoreboard {
    private String isActive;
    private int scoreOfTeamOne;
    private int scoreOfTeamTwo;
    private String teamOne;
    private String teamTwo;

    public Scoreboard(String one, String two) {
        teamOne = one;
        teamTwo = two;
        isActive = teamOne;
    }

    public void recordPlay(int points) {
        if (points == 0 && isActive == teamOne) {
            isActive = teamTwo;
        } else if (points == 0 && isActive == teamTwo) {
            isActive = teamOne;
        } else if (points > 0 && isActive == teamOne) {
            scoreOfTeamOne = scoreOfTeamOne + points;
        } else if (points > 0 && isActive == teamTwo) {
            scoreOfTeamTwo = scoreOfTeamTwo + points;
        }
    }

    public String getScore() {
        return scoreOfTeamOne + "-" + scoreOfTeamTwo + "-" + isActive;
    }
}