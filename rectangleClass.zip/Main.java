public class Main
{
	public static void main(String[] args) {
		//instantiate the rectangle class (invokes the constructor)
	    Rectangle myRectangle = new Rectangle(10,15);
		
		//invoke instance methods
		myRectangle.getPerimeter();
		System.out.println(myRectangle.getArea());
		
		
		//java automatically invokes the toString method when printing an object
		System.out.println(myRectangle);
		System.out.print(myRectangle.length);
		
	}
}
