public class Rectangle {
    // Instance properties
    private int length;
    private int height;
    
    // Constructor that sets both length and height
    public Rectangle(int l, int h) {
         length = l;
         height = h;
    }
    
    // Instance method to get perimeter
    public int getPerimeter() {
        int x = 2 * height + 2 * length;
        return x;
        System.out.print(x);
    }
    
    // Instance method to get area
    public int getArea() {
        return height * length;
    }
    
    // Instance method that returns a string representation
    public String toString() {
        String s = "Rectangle:";
        s += "\n\tlength: " + length;
        s += "\n\theight: " + height;
        s += "\n\tPerimeter: " + getPerimeter();
        s += "\n\tArea: " + getArea();
        return s;
    }
}