public static void main(String[] args) {

        ArrayList<Double> sampleTemps = new ArrayList<>();
        sampleTemps.add(89.1);
        sampleTemps.add(99.1);
        sampleTemps.add(79.1);
        sampleTemps.add(65.1);
        sampleTemps.add(55.0);
        sampleTemps.add(45.0);
        sampleTemps.add(101.0);
        sampleTemps.add(110.0);
        sampleTemps.add(120.0);
        sampleTemps.add(105.0);

        WeatherData wd = new WeatherData(sampleTemps);

        System.out.println("Data: " + wd);
        wd.cleanData(79, 110);
        System.out.println("After cleanData is implemented, we obtain: " + wd);
        System.out.println("Longest heat wave over 99: " + wd.longestHeatWave(99));
    }
