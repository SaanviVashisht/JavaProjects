import java.util.ArrayList;

public class WeatherData {
	private ArrayList<Double> initialTemps;

	public WeatherData(ArrayList<Double> arg) {
		initialTemps = new ArrayList<>(arg);
	}

	public void cleanData(double low, double high) {
		for (int i = 0; i < initialTemps.size(); i++) {
			double value = initialTemps.get(i);

			if (value < low || value > high) {
				initialTemps.remove(i);
				i--;
			}
		}
	}
	public int longestHeatWave(double threshold) {
		int longest = 0;
		int count = 0;
		for (int i = 0; i < initialTemps.size(); i++) {
			if (initialTemps.get(i) > threshold) {
				count++;
			} else {
				if (count > longest) {
					longest = count;
				}
				count = 0;
			}
		}

		if (count > longest) {
			longest = count;
		}
		return longest;
	}

	public String toString() {
		return initialTemps.toString();
	}
}