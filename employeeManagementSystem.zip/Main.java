public class Main {
    
   public static void main(String[] args) {
	Employee[] staff = new Employee[3];

	staff[0] = new HourlyEmployee("Alice", 25, 40);
	staff[1] = new SalariedEmployee("Bob", 104000);
	staff[2] = new CommissionEmployee("Charlie", 10, 8500);

	System.out.println("--- Employee Payroll Report ---");

	for (Employee emp : staff) {
		System.out.println(emp);
		System.out.println("-------------------------");
	}
   }
   
   ArrayList <Employee> employeeObjects = new ArrayList<>();
    
    
}