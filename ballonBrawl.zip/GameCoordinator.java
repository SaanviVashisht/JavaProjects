import java.util.Scanner;
import java.util.ArrayList;
public class GameCoordinator {
	private GameBoard gb;
	private int numRed;
	private int numBlue;

	public GameCoordinator() {
		gb = new GameBoard(8);
	}
	public void setupofTeams() {
		//Blue team
		for (int i = 0; i < 4; i++) {
			int r = (int)(Math.random() * 8);
			int c = (int)(Math.random() * 2);

			if (gb.getObject(r,c) == null) {
				gb.addGameObject(new Smasher("Blue"), r, c);
				numBlue++;
			} else i--;
		}

		//Red team
		for (int i = 0; i < 4; i++) {
			int r = (int)(Math.random() * 8);
			int c = 6 + (int)(Math.random() * 2);

			if (gb.getObject(r,c) == null) {
				gb.addGameObject(new Thrower("Red"), r, c);
				numRed++;
			} else i--;
		}
	}

	public void runGame() {
    /*Testing: gb.addGameObject(new Smasher("Blue"), 2, 1);
        	gb.addGameObject(new Thrower("Blue"), 5, 1);
        	gb.addGameObject(new Smasher("Red"), 2, 6);
        	gb.addGameObject(new Thrower("Red"), 5, 6);
        
        	numBlue = 2;
        	numRed = 2;*/
			System.out.println("Welcome to Balloon Brawl!");
			setupofTeams();
		    Scanner scanner = new Scanner(System.in);
			String currentTeam = "Blue";
			while (numRed > 0 && numBlue > 0) {
				System.out.println(gb);
				System.out.println(currentTeam + "'s turn");
				for (int i = 0; i < 3; i++) {

					System.out.println("Please enter command (move r1 c1 r2 c2 or attack r1 c1 r2 c2):");
					String input = scanner.nextLine();
					String[] parts = input.split(" ");

					if (parts.length != 5) {
						System.out.println("Invalid format.");
						i--;
					}
					ArrayList<Integer> nums = new ArrayList<>();

					try {
						for (int j = 1; j < parts.length; j++) {
							nums.add(Integer.parseInt(parts[j]));
						}
					} catch (Exception e) {
						System.out.println("Invalid numbers.");
						i--;
					}
					int r1 = nums.get(0);
					int c1 = nums.get(1);
					int r2 = nums.get(2);
					int c2 = nums.get(3);

					if (r1 < 0 || r1 >= 8 || c1 < 0 || c1 >= 8 ||
					        r2 < 0 || r2 >= 8 || c2 < 0 || c2 >= 8) {
						System.out.println("This is out of bounds.");
						i--;
					}
					GameObject attacker = gb.getObject(r1, c1);
					GameObject target = gb.getObject(r2, c2);

					if (attacker == null) {
						System.out.println("There is no object here.");
						i--;
					}

					if (!attacker.getTeam().equals(currentTeam)) {
						System.out.println("This is not your object.");
						i--;
					}
					String action = parts[0].toLowerCase();
			
					if (action.equals("move")) {
						int dist = GameBoard.kingDistance(r1,c1,r2,c2);

						if (dist <= attacker.getMoveRange() && target == null) {
							gb.addGameObject(attacker, r2, c2);
							gb.removeObject(r1, c1);
						} else {
							System.out.println("This is an invalid move.");
							i--;
						}
					}
	
					else if (action.equals("attack")) {
						if (target == null) {
							System.out.println("There is no target there.");
							i--;
						}

						int dist = GameBoard.euclideanDistance(r1,c1,r2,c2);
						if (dist <= attacker.getAttackRange()) {
							int damage = (int)(Math.random() * 3) + 1;
							target.takeDamage(damage);
							System.out.println("Damage: " + damage);

							if (target.getHealth() <= 0) {
								if (target.getTeam().equals("Blue")) numBlue--;
								else numRed--;
								gb.removeObject(r2, c2);
								System.out.println("Unit eliminated!");
							}
						} else {
							System.out.println("The target is too far.");
							i--;
						}
					}

					else {
						System.out.println("This is an invalid command.");
						i--;
					}
				}

				if (currentTeam.equals("Blue")) currentTeam = "Red";
				else currentTeam = "Blue";
			}

			System.out.println("Game Over!");
			if (numBlue > 0) System.out.println("Congrats, Blue team wins!");
			else System.out.println("Congrats, Red team wins!");
		}
	}