public class Main{
    
    public static void main(String[] args) {
        GameCoordinator gc = new GameCoordinator();
		gc.runGame();
        
    }
}