public class Thrower extends GameObject {
    // A Thrower has 5 health, 2 move range, and 4 attack range
    public Thrower(String team) {
        super("Thrower", team, 5, 2, 4);
    }
}