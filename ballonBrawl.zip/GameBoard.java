public class GameBoard {
	private GameObject [][] board;

	public GameBoard(int size) {
		this.board = new GameObject[size][size];
	}

	public void addGameObject(GameObject go, int row, int col) {
		board[row][col] = go;
	}

	public GameObject getObject(int row, int col) {
		return board[row][col];
	}

	public void removeObject(int row, int col) {
		board[row][col] = null;
	}

	public String toString() {
	String str = "";
	for (int i = 0; i < board.length; i++) {

		for (int x = 0; x < board[i].length; x++) {
			str += "----------------";
		}
		str += "-\n";

		for (int j = 0; j < board[i].length; j++) {
			if (board[i][j] == null)
				str += String.format("|%-15s", "");
			else
				str += String.format("|%-15s", "T:" + board[i][j].getTeam());
		}
		str += "|\n";

		for (int j = 0; j < board[i].length; j++) {
			if (board[i][j] == null)
				str += String.format("|%-15s", "");
			else
				str += String.format("|%-15s", board[i][j].getType());
		}
		str += "|\n";

		for (int j = 0; j < board[i].length; j++) {
			if (board[i][j] == null)
				str += String.format("|%-15s", "");
			else
				str += String.format("|%-15s", "HP:" + board[i][j].getHealth());
		}
		str += "|\n";
	}

	for (int x = 0; x < board[0].length; x++) {
		str += "----------------";
	}
	str += "-";

	return str;
}
	public static int euclideanDistance(int r1, int c1, int r2, int c2) {
		return (int)(Math.sqrt((r2-r1)*(r2-r1)+(c2-c1)*(c2-c1)));
	}

	public static int kingDistance(int r1, int c1, int r2, int c2) {
		return Math.max(Math.abs(r2-r1), Math.abs(c2-c1));
	}
	public static int manhattanDistance(int r1, int c1, int r2, int c2) {
        return Math.abs(r2-r1)+Math.abs(c2-c1);
    }
}
