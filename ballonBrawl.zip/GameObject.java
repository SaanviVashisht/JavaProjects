public abstract class GameObject {
    private String type;
    private int health;
    private int moveRange;
    private int attackRange;
    private String team;

    // Constructor
    public GameObject(String type, String team, int health, int moveRange, int attackRange) {
        this.type = type;
        this.team = team;
        this.health = health;
        this.moveRange = moveRange;
        this.attackRange = attackRange;
    }

    // Accessor Methods
    public String getType() {
        return type;
    }

    public int getHealth() {
        return health;
    }
    
    public String getTeam() {
        return team;
    }
    
    public int getMoveRange(){
        return moveRange;
    }
    public int getAttackRange(){
        return attackRange;
    }
    // Method to handle taking damage
    public void takeDamage(int damage) {
        if (damage > 0) {
            this.health -= damage;
            // Prevent health from dropping below zero
            if (this.health < 0) {
                this.health = 0;
            }
        }
    }
}