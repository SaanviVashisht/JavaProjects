public class Smasher extends GameObject {
    // A Smasher has 10 health, 4 move range, and 1 attack range
    public Smasher(String team) {
        super("Smasher", team, 10, 4, 1);
    }
}