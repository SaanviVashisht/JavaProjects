public class StateTransition{
    String currentState;
    char inputCharacter;
    String newState;
    char outputCharacter;
    String direction;
    
    public StateTransition(String cs, char ic, String ns, char oc, String di){
        currentState = cs;
        inputCharacter = ic;
        newState = ns;
        outputCharacter = oc;
        direction = di;
        
    }
    public String toString(){
        String s= "";
        s += "{"+"cs"+":"+currentState+" ";
        s += "ic"+":"+inputCharacter+" ";
        s += "ns"+":"+newState+" ";
        s += "oc"+":"+outputCharacter+" ";
        s += "di"+":"+direction+"}";
        return s;
        
    }
}