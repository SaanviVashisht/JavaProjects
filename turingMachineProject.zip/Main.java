public class Main{
    
    public static void main(String[] args){
        //define the test program as a String
        String inverter = """
    	1 0 1 1 r
    	1 1 1 0 r
    	1 _ 2 _ n
    	""";
	
	//instantiate our machine
    TuringVM myVM = new TuringVM();
    	
	//load our program, initial tape, initial head position, and initial state
    myVM.loadProgram(inverter, "10110_", 0, "1");
    	
	//run the program and display the trace
    System.out.println(myVM.runTuring());


    }
    
}
