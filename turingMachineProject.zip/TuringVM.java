import java.util.ArrayList;

public class TuringVM {
	ArrayList<StateTransition> transitionRules;
	char[] tape;
	int headPosition;
	String currentState;

	public TuringVM() {
		transitionRules = new ArrayList<StateTransition>();
		tape = new char[0];
		headPosition = 0;
		currentState = "";
	}

	public void loadProgram(String rulesList, String initialTape, int initialHead, String initialState) {
		transitionRules = new ArrayList<StateTransition>();
		String[] userInput = rulesList.split("\n");
		for (int i = 0; i < userInput.length; i++) {
			String individualLine = userInput[i].trim();
			if (!individualLine.equals("")) {
				String[] components = individualLine.split(" ");
				String cs = components[0];
				char ic = components[1].charAt(0);
				String ns = components[2];
				char oc = components[3].charAt(0);
				String di = components[4];
				StateTransition st = new StateTransition(cs, ic, ns, oc, di);
				transitionRules.add(st);
			}
		}
		tape = initialTape.toCharArray();
		headPosition = initialHead;
		currentState = initialState;
	}

	private String tapeAsString() {
		String finalResult = "";
		for (int i = 0; i < tape.length; i++) {
			if (i == headPosition) {
				finalResult = finalResult + "[" + tape[i] + "]";
			} else {
				finalResult = finalResult + tape[i];
			}
		}
		return finalResult;
	}
	
	public String runTuring() {
		String finalOutput = "";
		finalOutput = finalOutput + "State Transition Rules:\n";
		for (int i = 0; i < transitionRules.size(); i++) {
			finalOutput = finalOutput + transitionRules.get(i) + "\n";
		}

		finalOutput = finalOutput + "\n...running program...\n";
		int currentStep = 0;
		boolean runningThroughTape = true;
		while (runningThroughTape) {
			char currentChar = tape[headPosition];
			StateTransition rule = null;
			for (int i = 0; i < transitionRules.size(); i++) {
				StateTransition st = transitionRules.get(i);
				if (st.currentState.equals(currentState) &&
				        st.inputCharacter == currentChar) {
					rule = st;
					break;
				}
			}
			if (rule == null) {
				finalOutput = finalOutput + "...no state transition rule found, run complete...\n\n";
				runningThroughTape = false;
				break;
			} else {
				finalOutput = finalOutput + currentStep + ":\t";
				finalOutput = finalOutput + tapeAsString();
				finalOutput = finalOutput + "\t" + rule + "\n";
				tape[headPosition] = rule.outputCharacter;
				currentState = rule.newState;
				if (rule.direction.equals("r")) {
					headPosition = headPosition + 1;
				} else if (rule.direction.equals("l")) {
					headPosition = headPosition - 1;
				}
				if (rule.direction.equals("r") || rule.direction.equals("l")) {
					currentStep++;
				}
			}
		}
		finalOutput = finalOutput + "Final tape: " + tapeAsString() + "\n";
		finalOutput = finalOutput + "Final state: " + currentState + "\n";
		finalOutput = finalOutput + "Total steps: " + currentStep;
		return finalOutput;
	}
}