import java.util.ArrayList;
public class Main{
    
    public static void main(String[] args){
        //ArrayList <Double> testData = new ArrayList<>();
        //testData.add(45.1);
        //testData.add(47.4);
    	//testData.add(44.0);
    	//testData.add(51.8);
    	//testData.add(48.7);
    	//testData.add(41.0);
    	/*Stats s = new Stats("splat", testData);
    	System.out.println("Sum -> " + s.sum());
    	System.out.println("Mean -> " + s.mean());
    	System.out.println("Median -> " + s.median());
    	System.out.println("Standard Deviation: " + s.stdev());
    	System.out.println("Primes -> " + s.primes());
    	System.out.println("Name -> " + s.getName());
    	System.out.println("toString() -> " + s);
    	*/
    	
    StatsVC svc = new StatsVC();
    svc.runSystem();


    }
}