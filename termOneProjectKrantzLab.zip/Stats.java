import java.util.ArrayList;

public class Stats{
    
    //Instance Properties
    private String name;
    private ArrayList<Double> data;
    private ArrayList<Double> dataForToString; 

    
    //Constructor
    public Stats(String givenString, ArrayList<Double> givenArrayList){
        name = givenString;
        data= givenArrayList;
        dataForToString= new ArrayList(givenArrayList); //Since we are sorting "data", we need to assign ArrayList to "dataForToString"
    }                                                   //in order to access the original ArrayList that the user inputted
    

    //Instance Methods
    public Double sum(){
        double sum = 0.0;
        for (int i = 0; i < data.size(); i++) {
           sum=sum+data.get(i);
    }
    return sum;
    }
  
   public Double mean(){
        double sum = 0.0;
        double mean = 0.0;
        for (int i = 0; i < data.size(); i++) {
           sum=sum+data.get(i);
    }
    mean=sum/data.size();
    return mean;
    }
    
    public Double median(){
        data.sort(null);
        double median;
        int x;
        int y;
        double z;
        if (data.size()%2==0){
               x=data.size()/2;
               y=x-1;
               z = data.get(x)+data.get(y);
               median = z/2;
           }
        else{
            x=data.size()/2;
            median=data.get(x);
        }
           
    return median;
    }
    
    public Double stdev(){
        int denominator = data.size()-1;
        Double meanVal = mean();
        double sumOfElements=0.0;
        double element=0.0;
        for (int i = 0; i < data.size(); i++) {
           double x=(data.get(i)-meanVal)*(data.get(i)-meanVal);
           sumOfElements=sumOfElements+x;
    }
    return Math.sqrt(sumOfElements/denominator);
    }
    
    //Helper method
    private boolean isPrime(Integer n) {
    if (n < 2) return false;
    for (int i = 2; i <= Math.sqrt(n); i++) {
        if (n % i == 0) return false;
    }
    return true;
}
    
    public ArrayList<Integer> primes() {
    ArrayList<Integer> listOfPrimes = new ArrayList<>(); 
    
    for (int i = 0; i < data.size(); i++) {
        int num = data.get(i).intValue();  
        if (isPrime(num)==true) {               
            listOfPrimes.add(num);            
        }
    }

    return listOfPrimes;                     
}

//Getter
	public String getName(){
	    return name;
	}

//For user interface formatting
public String toString(){
    return name + ":"+" "+ dataForToString;
}

}
    

    
