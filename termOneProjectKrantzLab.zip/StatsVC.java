import java.util.ArrayList;
import java.util.Scanner;

public class StatsVC {
    //instance variables
    private ArrayList<Stats> dataSets;
    private Stats current; 

    //constructor
    public StatsVC() {
        dataSets = new ArrayList<Stats>();
        ArrayList<Double> defaultData = new ArrayList<Double>();
        for (double i = 1; i <= 5; i++) {
            defaultData.add(i);
        }
        Stats defaultDataSet = new Stats("default", defaultData);
        dataSets.add(defaultDataSet);
        current = defaultDataSet; 
    }

  
    public void runSystem() {
        Scanner scanner = new Scanner(System.in);
        String userInput = "";
        System.out.println("Welcome to the Krantz Lab. Type 'help' to see a list of commands.");

       
        while (!userInput.equals("quit")) {
            System.out.print("command...");
            userInput = scanner.nextLine();
            String[] dividedUserInput = userInput.split(" ");
            String input = dividedUserInput[0].toLowerCase();

           
            if (input.equals("help")) {
                System.out.println("*****COMMANDS*****");
                System.out.println("help - display this menu");
                System.out.println("info - display all data sets");
                System.out.println("add name d1 d2 d3 ... - add a new data set");
                System.out.println("current name - updates the active data set");
                System.out.println("sum - displays the sum of the active data set");
                System.out.println("mean - displays the mean of the active data set");
                System.out.println("median - displays the median of the active data set");
                System.out.println("stdev - displays the standard deviation of the active data set");
                System.out.println("primes - displays the primes of the active data set");
                System.out.println("quit - exits the system");

            } else if (input.equals("info")) {
                System.out.println("*****DATA SETS*****");
                for (Stats s : dataSets) {
                    if (s == current) {
                        System.out.println(" *" + s); 
                    } else {
                        System.out.println(" " + s);
                    }
                }

            } else if (input.equals("add")) {
                if (dividedUserInput.length < 3) {
                    System.out.println("ERROR: there is not enough information to add the dataset.");
                } else {
                    String name = dividedUserInput[1];
                    ArrayList<Double> nums = new ArrayList<Double>();
                    for (int i = 2; i < dividedUserInput.length; i++) {
                        double num = Double.parseDouble(dividedUserInput[i]);
                        nums.add(num);
                    }
                    Stats newDataSet = new Stats(name, nums);
                    dataSets.add(newDataSet);
                    
                }

            } else if (input.equals("current")) {
                if (dividedUserInput.length < 2) {
                    System.out.println("ERROR: must enter the dataset name.");
                } else {
                    String name = dividedUserInput[1];
                    Stats found = getDataSet(name);
                    if (found != null) {
                        current = found;
                    } else {
                        System.out.println("ERROR: dataset " + name + " is not found.");
                    }
                }

            } else if (input.equals("sum")) {
                System.out.println(current.sum());
            } else if (input.equals("mean")) {
                System.out.println(current.mean());
            } else if (input.equals("median")) {
                System.out.println(current.median());
            } else if (input.equals("stdev")) {
                System.out.println(current.stdev());
            } else if (input.equals("primes")) {
                System.out.println(current.primes());
            } else if (!input.equals("quit")) {
                System.out.println("ERROR: COMMAND " + input + " NOT UNDERSTOOD");
            }
        }

        System.out.println("...exiting system...");
        
    }

    //helper method 
    private Stats getDataSet(String name) {
        for (Stats s : dataSets) {
            if (s.getName().equals(name)) {
                return s;
            }
        }
        return null;
    }
}