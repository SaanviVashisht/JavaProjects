public abstract class Employee {
	private String name;
	private int id;
	private static int nextID = 1;

	public Employee(String n) {
		this.name = n;
		this.id = nextID;
		nextID++;
	}

	// Abstract method: Every subclass MUST provide its own version of this
	public abstract int computeWeeklySalary();

	public String toString() {
		String str = "Name: " + name + "\n";
		str += "ID: " + id + "\n";
		str += "Weekly Salary: $" + computeWeeklySalary();
		return str;
	}
}