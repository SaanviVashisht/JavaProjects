public class HourlyEmployee extends Employee {
	private int rate;
	private int numHours;

	public HourlyEmployee(String n, int r, int h) {
		super(n);
		this.rate=r;
		this.numHours=h;
	}

	public int computeWeeklySalary(){
	return (rate*numHours);
}
	public String toString() {
		return super.toString()+"\nHourly Rate: "+rate+"\nHours/Week: "+numHours;
	}

}


