public class CommissionEmployee extends Employee {
	private int commissionRate;
	private int weeklySales;

	public CommissionEmployee(String n, int r, int w) {
		super(n);
		this.commissionRate = r;
		this.weeklySales=w;
	}

	@Override
	public int computeWeeklySalary() {
		int num = this.commissionRate*this.weeklySales;
		int salary = num/100;
		return salary;
	}

	@Override
	public String toString() {
		return super.toString()+"\nCommission Rate: "+commissionRate+"\nWeekly Sales: "+weeklySales;
	}
}