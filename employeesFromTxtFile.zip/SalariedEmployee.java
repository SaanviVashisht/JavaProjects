public class SalariedEmployee extends Employee {
	private int annualSalary;

	public SalariedEmployee(String n, int a) {
		super(n);
		this.annualSalary = a;
	}
	@Override
	public int computeWeeklySalary() {
		return this.annualSalary/52;
	}

	@Override
	public String toString() {
		return super.toString()+"\nAnnual salary: "+annualSalary;
	}
}