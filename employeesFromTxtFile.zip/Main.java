import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    
   public static void main(String[] args) {
	Employee[] staff = new Employee[3];

	staff[0] = new HourlyEmployee("Alice", 25, 40);
	staff[1] = new SalariedEmployee("Bob", 104000);
	staff[2] = new CommissionEmployee("Charlie", 10, 8500);

	System.out.println("--- Employee Payroll Report ---");

	for (Employee emp : staff) {
		System.out.println(emp);
		System.out.println("-------------------------");
	}
	
	  ArrayList <Employee> employeeObjects = new ArrayList<>();
	  File file = new File("employees.txt");
	  try{
	  Scanner input = new Scanner(file);
	  while (input.hasNext()){
	      String type = input.next();
	      String name = input.next();
	      if (type.equals("H")){
	         int h = input.nextInt();
	         int r = input.nextInt();
	         employeeObjects.add(new HourlyEmployee(name, r, h));
	         
	       if(type.equals("S")){
	           int a = input.nextInt();
	           employeeObjects.add(new SalariedEmployee(name, a));
	       }
	       if (type.equals("C")){
	           int r1 = input.nextInt();
	           int w = input.nextInt();
	           employeeObjects.add(new CommissionEmployee(name, r1, w ));  //rate first
	       }
	  }
   }
   
   } catch (FileNotFoundException e) {
        System.out.println("This file is not found.");
}
    for(Employee e:employeeObjects){
        System.out.println(e);
        System.out.println("--------");
    }
}
}
