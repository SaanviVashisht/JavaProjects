import java.util.Scanner;
import java.util.ArrayList;

public class Main
{
	public static void main(String[] args) {
	    ArrayList<XYPair> vertices = new ArrayList<XYPair>();
	    
	    /* x and y coordinates:
	    */
	    System.out.println("Please enter the x1 coordinate: ");
	    Scanner scanner = new Scanner(System.in);
	    double x1Input = scanner.nextDouble();
	    System.out.println("Please enter the y1 coordinate: ");
	    double y1Input = scanner.nextDouble();
	    
	    System.out.println("Please enter the x2 coordinate: ");
	    double x2Input = scanner.nextDouble();
	    System.out.println("Please enter the y2 coordinate: ");
	    double y2Input = scanner.nextDouble();
	    
	    System.out.println("Please enter the x3 coordinate: ");
	    double x3Input = scanner.nextDouble();
	    System.out.println("Please enter the y3 coordinate: ");
	    double y3Input = scanner.nextDouble();
	    System.out.println();
	   
	    
	    XYPair firstPoint= new XYPair(x1Input,y1Input);
	    XYPair secondPoint= new XYPair(x2Input,y2Input);
	    XYPair thirdPoint= new XYPair(x3Input,y3Input);
	    
	    vertices.add(firstPoint);
	    vertices.add(secondPoint);
	    vertices.add(thirdPoint);
	    
	    double side1 = firstPoint.distanceTo(secondPoint);
	    double side2 = secondPoint.distanceTo(thirdPoint);
	    double side3 = thirdPoint.distanceTo(firstPoint);
	    
	    double perimeter = side1+side2+side3;
	    System.out.print("Your triangle's vertices are: ");
	    System.out.println(vertices);
	    System.out.println("Perimeter: "+perimeter);
	    
	    double s = perimeter/2;
	    double area = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
	    System.out.println("Area: "+area);
        
	}
}

	       
