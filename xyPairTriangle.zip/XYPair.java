class XYPair {
    private double x;
    private double y;
    
    public XYPair(double x, double y) {
        this.x = x;
        this.y = y;
    }
    
    public double distanceTo(XYPair otherPoint) {
        return Math.sqrt((this.x-otherPoint.x)*(this.x-otherPoint.x) + (this.y-otherPoint.y)*(this.y-otherPoint.y));
    }
    
    public double slopeBetween(XYPair otherPoint) {
        return (this.y-otherPoint.y)/(this.x-otherPoint.x);
    }
    
    public String equationOfLineThrough(XYPair otherPoint) {
        return "y - " + this.y + " = " + this.slopeBetween(otherPoint)+"(x - "+this.x+")";
    }
    
    public String toString() {
        return "("+this.x+", "+this.y+")";
    }
    
    public static double getPerimeter(ArrayList<XYPair> vertices)
    for (int i = 0; i < vertices.size(); i++) {
        return Math.sqrt((vertices(i+1)-vertices(i))*(vertices(i+1)-vertices(i)) + (this.y-otherPoint.y)*(this.y-otherPoint.y));
    
	  }
}