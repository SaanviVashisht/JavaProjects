public class Main
{
	public static void main(String[] args) {
	Matrix sample = new Matrix(3, 5);
    /*System.out.println(sample.getValue(0, 0));
    sample.setValue(0, 0, 1);
    sample.setValue(1, 0, 1);
    sample.setValue(2, 1, 1);
    sample.setValue(2, 3, 1);
    System.out.println(sample);
    System.out.println(sample.sumRow(2));
    System.out.println(sample.sumCol(3));
    System.out.println(sample.numOccurences(1));
    System.out.println(sample.numZeroes());
    sample.rowSwap(0, 2);
    System.out.println(sample);
    sample.fill(9);
    System.out.println(sample);
    sample.clear();
    System.out.println(sample);
	}
}
*/
System.out.println(sample.toString());

}
}