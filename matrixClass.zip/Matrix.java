public class Matrix {
    private int[][] mat;
    private int numRows;
    private int numCols;
    
    public Matrix(int Rows, int Cols) {
        this.mat = new int[numRows][numCols];
        numRows = Rows;
        numCols = Cols;
       
    }
    
    public int getValue(int r, int c){
        return mat[r][c];
    }
    
   public void setValue(int r, int c, int newValue){
        this.mat[r][c]=newValue;
}
    
    
    public String toString(){
        String s = "";
        for(int i=0; i<this.mat.length; i++){
            for(int j=0; j<this.mat[i].length; j++){
                s = s+ mat[i][j]+" ";
            }
            s=s+"\n";
        }
        return s;
    }
    
    public void fill(int value){
        for(int i=0; i<this.mat.length; i++){
            for(int j=0; j<this.mat[i].length; j++){
               this.mat[i][j] = value;
            }
        }
    }
    
    public void clear(){
        fill(0);
    }

    public int sumRow(int r){
        int sum = 0;
        for(int j = 0; j < this.mat[r].length; j++){
            sum += this.mat[r][j];
        }
        return sum;
    }
    
    public int sumCol(int c){
        int sum = 0;
        for(int i = 0; i < this.mat.length; i++){
            sum += this.mat[i][c];
        }
        return sum;
    }
    public int numOccurences(int target){
        int count = 0;
        for(int i=0; i<this.mat.length; i++){
            for(int j=0; j<this.mat[i].length; j++){
               if (this.mat[i][j] == target){
                   count++;
               }
    }
    }
    return count;
}
    public int numZeroes(){
        return numOccurences(0);
    }
      public void rowSwap(int r1, int r2){
        int[] temp = this.mat[r1];
        this.mat[r1] = this.mat[r2];
        this.mat[r2] = temp;
    }
    
    public int sumSurrounding(int r, int c){
       int sumNormalCase = 0;
       int row1 = r-1;
       int row2 = r+1;
       int col1 = c-1;
       int col2 = c+1;
       int rowNormalCase1= this.mat[row1][c];
       int rowNormalCase2= this.mat[row2][c];
       int colNormalCase1= this.mat[r][col1];
       int colNormalCase2= this.mat[r][col2];
       int diagnoalNormalCase1 = this.mat[row2][col1];
       int diagnoalNormalCase2 = this.mat[row1][col2];
       sumNormalCase += rowNormalCase1+rowNormalCase2+colNormalCase1+colNormalCase2+diagnoalNormalCase1+diagnoalNormalCase2;
       return sumNormalCase;
    }
}

