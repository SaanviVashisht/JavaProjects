public class Scoreboard {
	private String active; 
	private int score1;
	private int score2;
	private String team1;
	private String team2;

Scoreboard(String x, String y){
team1=x;
team2=y;
this.active = team1;
}
public void recordPlay(int x){
	if(x == 0) {
		if(this.active == this.team1)
        this.active = this.team2;
	else{
    this.active = this.team1;
	}
}
this.score1=score1+x;
this.score2=score2+x;
}



public String getScore() {
	return this.score1 + "-" + this.score1+ "-" + this.active;
	return this.score2 + "-" + this.score2+ "-" + this.active;

}
}
